import { v4 as uuid } from "uuid";

let uuser=[];

export const  getUsers=(req,res)=>{
    res.send(uuser)
}

export const createUsers =(req,res)=>{
    const user=req.body;

    uuser.push({...user,id:uuid()});
    res.send("User Added Successfully");
}

export const GetUsersById=(req,res)=>{
    const singleUser=uuser.filter((user)=>user.id === req.params.id);
    res.send(singleUser)
}

export const DeleteUsersById=(req,res)=>{
    uuser=uuser.filter((user)=>user.id !== req.params.id);
    res.send("User Deleted Successfully");
}

export const UpdateUsersById=(req,res)=>{
    const user=uuser.find((user)=>user.id===req.params.id);
    
    user.name=req.body.name;
    user.email=req.body.email;
    user.contact=req.body.contact;
    user.Gender=req.body.Gender;
    res.send("User Updated Successfully");
}