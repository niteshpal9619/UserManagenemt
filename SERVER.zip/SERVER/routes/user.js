import express  from "express";

import {getUsers,createUsers,GetUsersById,DeleteUsersById,UpdateUsersById} from "../controllers/user.js"

const router=express.Router();

router.get("/users",getUsers);
router.post("/users",createUsers);
router.get("/users/:id",GetUsersById);
router.delete("/users/:id",DeleteUsersById);
router.put("/users/:id",UpdateUsersById);

export default router